import React, { Component , useState} from "react";
import { connect } from "react-redux";
import { Button, Card, CardTitle, CardSubtitle, CardBody, Form, FormGroup, Label, Input, Modal, ModalHeader, ModalBody, ModalFooter , Spinner } from "reactstrap";
import PropTypes from "prop-types";
import "./style.css";
import { Redirect } from "react-router-dom";
import { logout } from "../actions/authActions";
import { buttonReset } from "../actions/uiActions";



export class Profile extends Component {
  static propTypes = {
    button: PropTypes.bool,
    authState: PropTypes.object.isRequired,
    buttonReset: PropTypes.func.isRequired,
    logout: PropTypes.func.isRequired,
  };

  

  constructor(props) {
    super(props);

    this.state = { result: 0, modal: false };
    // added
    this.toggle = this.toggle.bind(this);

  }

  toggle() {
    this.setState({
      modal: !this.state.modal
    });
  }
  

  onLogout = (e) => {
    e.preventDefault();
    this.props.buttonReset();
    this.props.logout();
  };

  componentDidMount() {
    this.handleGetResult();
  }


  handleGetResult = async () => {
    let res = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=kkongnotyuniverse&vs_currencies=usd"
    )
      .then((response) => response.json())
      .then((data) => {
        const { user } = this.props.authState;
        const balance = Number(user?.balance);

        this.setState({
          result: Number(data?.kkongnotyuniverse.usd) * balance,
        });
      });
  };

  render() {
    if (!this.props.authState.isAuthenticated) {
      return <Redirect to="/" />;
    }

    const { user } = this.props.authState;


    return (
      <div className="container">
        <div className="main">
          <img alt='logo' src="img/KUT logo_white.png" width={100} />
          <br /> <br />
          <Card>
            <CardBody style={{backgroundColor: '#000000'}}>
              <CardTitle>
                <h1>
                  {user ? `Welcome, ${user.name}, ` : ""}{" "}
                  <span role="img" aria-label="party-popper">
                    🎉{" "}
                  </span>{" "}
                </h1>
              </CardTitle>
              <br />
              <CardSubtitle>
              <h5>{user ? `Lock-up balance : ${user.balance.toLocaleString('en-US')} KUT` : ""}{" "}</h5>
              <h5>Lock-up value in USD : </h5>  <h5>$ {this.state?.result.toLocaleString('en-US')} </h5>
                
              </CardSubtitle>
              <br />
              <CardTitle><h5 style={{ color: '#8dfcc4' }}>{user ? ` 1st Release : ${user.release1}` : ""} <span role="img" aria-label="party-popper"> </span> </h5></CardTitle>
              <CardTitle><h5 style={{ color: '#8dfcc4' }}>{user ? ` 2nd Release : ${user.release2}` : ""} <span role="img" aria-label="party-popper"> </span> </h5></CardTitle>
              <br />
              <CardSubtitle>
                <h5>My Address : </h5> <h5 style={{ fontSize: "14px" }}>{user?.address} </h5>
              </CardSubtitle>
              <br />

              <div>
              <Button color="danger" onClick={this.toggle}>{this.props.buttonLabel}Export Private Key</Button>
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className}>
                  <ModalHeader toggle={this.toggle}>Warning : Never disclose this key.</ModalHeader>
                  <ModalBody style={{ fontSize: "12px" }}>{user?.key}</ModalBody>
                  <ModalFooter>
                    <Button color="primary" onClick={this.toggle}>Close</Button>{' '}
                  </ModalFooter>
                </Modal>
                
              </div>
                
              

              

              <br />
              
              <br />


              <Button size="lg" onClick={this.onLogout} color="primary">
                Logout
              </Button>
            </CardBody>
          </Card>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  //Maps state to redux store as props
  button: state.ui.button,
  authState: state.auth,
});



export default connect(mapStateToProps, { logout, buttonReset })(Profile);
