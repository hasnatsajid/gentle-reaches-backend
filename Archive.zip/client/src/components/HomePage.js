import React, { Component, useEffect } from 'react';
import Login from './Login';
import Register from './Register';
import { connect } from "react-redux";
import { Route, Switch, Link } from 'react-router-dom'
import {
  Button,
} from "reactstrap";
import PropTypes from "prop-types";
import { buttonClicked } from "../actions/uiActions";
import './style.css';
import store from '../store';
import { isAuth } from '../actions/authActions'
import {Redirect} from 'react-router-dom'
import { useTranslation } from 'react-i18next';
import i18next from 'i18next';
import cookies from 'js-cookie'
import classNames from 'classnames'

const languages = [
  {
    code: 'ko',
    name: 'Korean',
    country_code: 'ko',
  },
  {
    code: 'en',
    name: 'English',
    country_code: 'gb',
  }
]


var divStyle = {
color:'white'
};

export class HomePage extends Component {




  componentDidMount() {
    // Check if session cookie is present
    store.dispatch(isAuth());
  }

  static propTypes = {
    button: PropTypes.bool,
    isAuthenticated: PropTypes.bool,
  };

  handleClick(lang) {
    i18next.changeLanguage(lang)
  }
  

  render() {
    const currentLanguageCode = cookies.get('i18next') || 'en'
    const currentLanguage = languages.find((l) => l.code === currentLanguageCode)
    const { t } = useTranslation()

    useEffect(() => {
      console.log('Setting page stuff')
      document.body.dir = currentLanguage.dir || 'ltr'
      document.title = t('app_title')
    }, [currentLanguage, t])


    if(this.props.isAuthenticated) {
      return <Redirect to="/profile" />
    }

  

    return (
      
       <div className="container">
       
        <div className="main">
          <nav style={{ width: '100%', padding:'2rem 0', backgroundColor:'black' }} >
            <button onClick={() => this.handleClick('en')} >
              English
            </button>
            <button onClick={() => this.handleClick('ko')} >
              Korean
            </button>
          </nav>
          {/* <img alt='logo' src="img/KUT logo_white.png" width={300}/> */}
          <br/> <br/>
            
            <p>{t('balance.1')}</p>
            
            <h5 style={divStyle}>{t('balance.1')}<span role="img" aria-label="lock">🔒,  </span><br></br>{t('date.1')}</h5>
          <br/>
          <div>

            <Switch>
              <Route exact path ="/login" component={Login}/>
              <Route exact path ="/register" component={Register}/>
            </Switch>

             { this.props.button && <Link className='divStyle' to="/login">
               <Button size="lg"  color="light">Sign In</Button>
               </Link>}

             {this.props.button && <Link className='divStyle' to="/register">
               <Button  size="lg"  color="light">Register</Button>
             </Link>}

             

          </div>
        </div>
    </div>
    )
  }
}
const mapStateToProps = (state) => ({ //Maps state to redux store as props
  button: state.ui.button,
  isAuthenticated: state.auth.isAuthenticated

});

export default connect(mapStateToProps)(HomePage);
